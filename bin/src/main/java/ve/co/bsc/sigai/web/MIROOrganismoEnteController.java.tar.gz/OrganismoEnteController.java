/*
 * Licencia GPL v3
 * 
 * Copyright (C) 2013 Centro Nacional de Tecnologías de Información.
 * SIGEFUAI Sistema de Informacion Gerencial de Fortalecimiento de las Unidades de Auditoria Interna
 * 
 * Copyright (C) 2013 Ehison Perez, Gerardo Perez @gerardoperez132, Alexis Veliz. All Rights Reserved.
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or any
 * later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see http://www.gnu.org/licenses
 */

package ve.co.bsc.sigai.web;

import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.roo.addon.web.mvc.controller.RooWebScaffold;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import ve.co.bsc.sigai.domain.Ciudad;
import ve.co.bsc.sigai.domain.CodigoArea;
import ve.co.bsc.sigai.domain.DatosOrganismoEnte;
import ve.co.bsc.sigai.domain.Estado;
import ve.co.bsc.sigai.domain.EstadoAuditor;
import ve.co.bsc.sigai.domain.Municipios;
import ve.co.bsc.sigai.domain.OrganismoEnte;
import ve.co.bsc.sigai.domain.Personalizacion;
import ve.co.bsc.sigai.domain.TipoOrganismo;
import ve.co.bsc.sigai.domain.TipoPersonaRif;
import ve.co.bsc.sigai.form.OrganismoEnteForm;
import ve.co.bsc.util.Util;

//import com.sun.star.bridge.oleautomation.Date;

@RooWebScaffold(path = "organismoente", automaticallyMaintainView = true, formBackingObject = OrganismoEnte.class)
@RequestMapping("/organismoente/**")
@SessionAttributes({ "organismoEnte", "datosOrganismoEnte" })
@Controller
public class OrganismoEnteController {
	private static String estatus;

	/**
	 * 
	 * @param datosOrganismoEnte
	 * @param result
	 * @param modelMap
	 * @param request
	 * @param status
	 * @return
	 */
	@RequestMapping(value = "/organismoente", method = RequestMethod.POST)
	public String create(
			// @Valid OrganismoEnte organismoEnte,
			@Valid @ModelAttribute("datosOrganismoEnte") OrganismoEnteForm datosOrganismoEnte,
			BindingResult result, ModelMap modelMap,
			HttpServletRequest request, SessionStatus status) {

		/* Cableo Hacia Personalizacion */
		/** Extraigo los Datos **/
		String nombre = datosOrganismoEnte.getOrganismoEnte().getNombre();
		String rif = datosOrganismoEnte.getOrganismoEnte().getRif();
		String paginaWeb = datosOrganismoEnte.getDatosOrganismoEnte()
				.getPagina_web();
		String direccion = datosOrganismoEnte.getDatosOrganismoEnte()
				.getDirecion();
		Estado estado = datosOrganismoEnte.getDatosOrganismoEnte().getEstado();
		int telefonoMaster = datosOrganismoEnte.getDatosOrganismoEnte()
				.getTelefono_master();

		/** Extraigo los Datos **/
		/** Valido que los Datos a registrar en personalizacion no van nulos **/
		if (nombre != null) {
			datosOrganismoEnte.getPersonalizacion()
					.setNombreInstitucion(nombre);
		}
		if (paginaWeb != null) {
			datosOrganismoEnte.getPersonalizacion().setWeb(paginaWeb);
		}
		if (direccion != null) {
			datosOrganismoEnte.getPersonalizacion().setDireccion(direccion);
		}
		if (estado != null) {
			datosOrganismoEnte.getPersonalizacion().setEstado(estado);
		}
		
		
		
		
		/* Concateno el Codigo de area con el telefono */
		String tel = String.valueOf(datosOrganismoEnte.getDatosOrganismoEnte()
				.getCodigoArea().getCodigo())
				+ "-" + String.valueOf(telefonoMaster);
		datosOrganismoEnte.getPersonalizacion().setTelefonoMaster(tel);
	//	datosOrganismoEnte.getDatosOrganismoEnte().getTelefono_master(Integer.parseInt(tel));

		String fax = String.valueOf(datosOrganismoEnte.getDatosOrganismoEnte()
				.getCodigoArea().getCodigo())
				+ "-"
				+ datosOrganismoEnte.getPersonalizacion().getTelefonoFax();
		datosOrganismoEnte.getPersonalizacion().setTelefonoFax(fax);
		/* Concateno el Codigo de area con el telefono */
		/* Carga de Rif Con Letra segun tipo */
		TipoPersonaRif tiporif = datosOrganismoEnte.getOrganismoEnte()
				.getTipo_rif();
		long tipo = tiporif.getId();

		List<TipoPersonaRif> t = TipoPersonaRif.findAllTipoPersonaRifs();
		String r = null;
		for (TipoPersonaRif tt : t) {
			long idTipo = tt.getId();

			if (idTipo == tipo) {
				String TipoRif = tt.getNombre();
				r = TipoRif.substring(0, 1) + "-" + rif;
				break;
			}
		}
		/* Carga de Rif Con Letra segun tipo */
		/***** Valido si el Rif no se encuentra Registrado *******/
		// int a = 0;
		List<OrganismoEnte> OrganismoEnteRifList = OrganismoEnte
				.findAllOrganismoEntes();
		for (OrganismoEnte d : OrganismoEnteRifList) {
			String b = d.getRif();
			if (b.equals(r)) {
				result.addError(new ObjectError("rif",
						"Este rif se encuentra registrado en el sistema" + r
								+ "TipoRif" + tiporif.getId()));
				// variable = d.getId();
				// a = 1;
				break;
			}
		}
		/***** Valido si el Rif no se encuentra Registrado *******/
		/* Se autoRegistra la Fecha de Creacion */
		java.util.Date FechaActual = new Date();
		datosOrganismoEnte.getOrganismoEnte().setFechaCreacion(FechaActual);
		datosOrganismoEnte.getOrganismoEnte().setFechaModificacion(FechaActual);
		/***
		 * Valido Que el Ente Tutelar Este vacio cuado El organismo no depende
		 * de Ninguno
		 ***/
		if (datosOrganismoEnte.getEffectTypes() == 1) {
			datosOrganismoEnte.getOrganismoEnte().setId_organismo_padre(null);
			datosOrganismoEnte.getPersonalizacion().setNombreTutelar(
					"No Posee un Ente Tutelar");
		} else if (datosOrganismoEnte.getEffectTypes() == 2) {
			datosOrganismoEnte.getPersonalizacion().setNombreTutelar(
					datosOrganismoEnte.getOrganismoEnte()
							.getId_organismo_padre().getNombre().toString());
		}
		/***
		 * Valido Que el Ente Tutelar Este vacio cuado El organismo no depende
		 * de Ninguno
		 ***/

		if (datosOrganismoEnte == null)
			throw new IllegalArgumentException("A organismoEnte is required");
		if (result.hasErrors()) {
			modelMap.addAttribute("datosOrganismoEnte", datosOrganismoEnte);
			modelMap.addAttribute("estadoauditors",
					EstadoAuditor.findAllEstadoAuditors());
			modelMap.addAttribute("estadoes", Estado.findAllEstadoes());
			modelMap.addAttribute("ciudads", Ciudad.findAllCiudads());
			modelMap.addAttribute("municipioses",
					Municipios.findAllMunicipioses());
			modelMap.addAttribute("codigoareas",
					CodigoArea.findAllCodigoAreas());
			modelMap.addAttribute("tipoorganismoes",
					TipoOrganismo.findAllTipoOrganismoes());
			modelMap.addAttribute("tipopersonarifs",
					TipoPersonaRif.findAllTipoPersonaRifs());
			return "organismoente/create";
		}
		/* Cableo el Rif en las 2 tablas: Personalizacion y Datos Organismo Ente */
		//datosOrganismoEnte.getOrganismoEnte().setRif(r);
		datosOrganismoEnte.getDatosOrganismoEnte().setRif(r); //DatosOrganismoEnte
		datosOrganismoEnte.getPersonalizacion().setRif(r);    //Personalizacion
		/* Cableo el Rif en las 2 tablas: Personalizacion y Datos Organismo Ente */
		datosOrganismoEnte.getDatosOrganismoEnte().persist(); //Guardo en DatosOrganismoEnte
		datosOrganismoEnte.getOrganismoEnte().persist();      //Guardo en OrganismoEnte
		String ciudad = datosOrganismoEnte.getDatosOrganismoEnte()
				.NombreCiudad(); // Extraigo la ciudad
		datosOrganismoEnte.getPersonalizacion().setCiudad(ciudad); //Guardo la Ciudad en Personalizacion
		datosOrganismoEnte.getPersonalizacion().setTipoOrganismo(
				datosOrganismoEnte.getOrganismoEnte().getId_tipo_organismo()); //Guardo el tipo de organismo en Personalizacion
		
		datosOrganismoEnte.getPersonalizacion().persist(); //Guardo en personalizacion
		status.setComplete();
		return "redirect:/organismoente/";
	}

	/**
	 * 
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "/organismoente/form", method = RequestMethod.GET)
	public String createForm(ModelMap modelMap) {
		

		modelMap.addAttribute("datosOrganismoEnte", new OrganismoEnteForm());
        
		modelMap.addAttribute("estadoauditors",
				EstadoAuditor.findAllEstadoAuditors());
		modelMap.addAttribute("estadoes", Estado.findAllEstadoes());
		modelMap.addAttribute("ciudads", Ciudad.findAllCiudads());
		modelMap.addAttribute("municipioses", Municipios.findAllMunicipioses());
		modelMap.addAttribute("codigoareas", CodigoArea.findAllCodigoAreas());
		modelMap.addAttribute("organismoentes",
				OrganismoEnte.findAllOrganismoEntes());
		modelMap.addAttribute("tipoorganismoes",
				TipoOrganismo.findAllTipoOrganismoes());
		modelMap.addAttribute("tipopersonarifs",
				TipoPersonaRif.findAllTipoPersonaRifs());
		return "organismoente/create";
	}

	/**
	 * 
	 * @param datosOrganismoEnte
	 * @param result
	 * @param modelMap
	 * @param request
	 * @param status
	 * @return
	 */
	@RequestMapping(method = RequestMethod.PUT)
	public String update(
			@Valid @ModelAttribute("datosOrganismoEnte") OrganismoEnteForm datosOrganismoEnte,
			BindingResult result, ModelMap modelMap,
			HttpServletRequest request, SessionStatus status) {
		Util util = new Util();
		java.util.Date FechaActual = new Date();
		datosOrganismoEnte.getOrganismoEnte().setFechaModificacion(FechaActual);
		/***
		 * Valido Que el Ente Tutelar Este vacio cuado El organismo no depende
		 * de Ninguno
		 ***/
		if (datosOrganismoEnte.getEffectTypes() == 2) {
			datosOrganismoEnte.getOrganismoEnte().setId_organismo_padre(null);
			datosOrganismoEnte.getPersonalizacion().setNombreTutelar(
					"No Posee un Ente Tutelar");
		} else if (datosOrganismoEnte.getEffectTypes() == 1) {
			datosOrganismoEnte.getPersonalizacion().setNombreTutelar(
					datosOrganismoEnte.getOrganismoEnte()
							.getId_organismo_padre().getNombre().toString());
		}
		/***
		 * Valido Que el Ente Tutelar Este vacio cuado El organismo no depende
		 * de Ninguno
		 ***/
		/**/
		/** Extraigo los Datos **/
		String nombre = datosOrganismoEnte.getOrganismoEnte().getNombre();
		String rif = datosOrganismoEnte.getOrganismoEnte().getRif();
		String paginaWeb = datosOrganismoEnte.getDatosOrganismoEnte()
				.getPagina_web();
		String direccion = datosOrganismoEnte.getDatosOrganismoEnte()
				.getDirecion();
		Estado estado = datosOrganismoEnte.getDatosOrganismoEnte().getEstado();
		int telefonoMaster = datosOrganismoEnte.getDatosOrganismoEnte()
				.getTelefono_master();

		/** Extraigo los Datos **/
		/** Valido que los Datos a registrar en personalizacion no van nulos **/
		if (nombre != null) {
			datosOrganismoEnte.getPersonalizacion()
					.setNombreInstitucion(nombre);
		}
		if (paginaWeb != null) {
			datosOrganismoEnte.getPersonalizacion().setWeb(paginaWeb);
		}
		if (direccion != null) {
			datosOrganismoEnte.getPersonalizacion().setDireccion(direccion);
		}
		if (estado != null) {
			datosOrganismoEnte.getPersonalizacion().setEstado(estado);
		}
		/** Valido que los Datos a registrar en personalizacion no van nulos **/
		/**/
		datosOrganismoEnte.getPersonalizacion().setCiudad(datosOrganismoEnte.getDatosOrganismoEnte()
				.NombreCiudad()); //Guardo la Ciudad en Personalizacion
		datosOrganismoEnte.getPersonalizacion().setTipoOrganismo(
				datosOrganismoEnte.getOrganismoEnte().getId_tipo_organismo()); //Guardo el tipo de organismo en Personalizacion
		
		/* Concateno el Codigo de area con el telefono */
		String tel = String.valueOf(datosOrganismoEnte.getDatosOrganismoEnte()
				.getCodigoArea().getCodigo())
				+ "-" + String.valueOf(telefonoMaster);
		datosOrganismoEnte.getPersonalizacion().setTelefonoMaster(tel);
	//	datosOrganismoEnte.getDatosOrganismoEnte().getTelefono_master(Integer.parseInt(tel));

		String fax = String.valueOf(datosOrganismoEnte.getDatosOrganismoEnte()
				.getCodigoArea().getCodigo())
				+ "-"
				+ datosOrganismoEnte.getPersonalizacion().getTelefonoFax();
		datosOrganismoEnte.getPersonalizacion().setTelefonoFax(fax);
		/* Concateno el Codigo de area con el telefono */
		
		if (datosOrganismoEnte == null)
			throw new IllegalArgumentException("A organismoEnte is required");
		if (result.hasErrors()) {
			modelMap.addAttribute("datosOrganismoEnte", datosOrganismoEnte);
			modelMap.addAttribute("estadoes", Estado.findAllEstadoes());
			modelMap.addAttribute("ciudads", Ciudad.findAllCiudads());
			modelMap.addAttribute("municipioses",
					Municipios.findAllMunicipioses());
			modelMap.addAttribute("codigoareas",
					CodigoArea.findAllCodigoAreas());
			modelMap.addAttribute("estadoauditors",
					EstadoAuditor.findAllEstadoAuditors());
			modelMap.addAttribute("organismoentes",
					OrganismoEnte.findAllOrganismoEntes());
			modelMap.addAttribute("tipoorganismoes",
					TipoOrganismo.findAllTipoOrganismoes());
			modelMap.addAttribute("tipopersonarifs",
					TipoPersonaRif.findAllTipoPersonaRifs());
			return "organismoente/update";
		}
		String estatusN = datosOrganismoEnte.getOrganismoEnte().getEstatus()
				.getNombre();
		String out = util.rolUsuarioLoggeado();
		if (!out.equals("[ADMIN_INSTITUCION]")) {
			if (estatus.equals("Activo")) {
				if (estatusN.equals("Inactivo")) {
					util.desabilitarUsuariosAuditores(datosOrganismoEnte
							.getOrganismoEnte());
					util.desabilitarUsuariosAuditados(datosOrganismoEnte
							.getOrganismoEnte());
				}
			} else if (estatus.equals("Inactivo")) {
				if (estatusN.equals("Activo")) {
					util.habilitarUsuariosAuditores(datosOrganismoEnte
							.getOrganismoEnte());
					util.habilitarUsuariosAuditados(datosOrganismoEnte
							.getOrganismoEnte());
				}
			}
		}
		datosOrganismoEnte.getDatosOrganismoEnte().merge();
		datosOrganismoEnte.getOrganismoEnte().merge();
		datosOrganismoEnte.getPersonalizacion().merge();
		status.setComplete();
		return "redirect:/organismoente/";
	}

	/**
	 * 
	 * @param id
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "/organismoente/{id}/form", method = RequestMethod.GET)
	public String updateForm(@PathVariable("id") Long id, ModelMap modelMap) {
		long variable = 0;

		if (id == null)
			throw new IllegalArgumentException("An Identifier is required");
		OrganismoEnteForm datosOrganismoEnte = new OrganismoEnteForm();
		datosOrganismoEnte
				.setOrganismoEnte(OrganismoEnte.findOrganismoEnte(id));

		// traer datos de la tabla Personalizacion para su actualizacion
		Query query = Personalizacion
				.findPersonalizacionsByRifEquals(datosOrganismoEnte
						.getOrganismoEnte().getRif().toString());
		List<Personalizacion> list = query.getResultList();
		for (Personalizacion per : list) {
			variable = per.getId();
			break;
		}
		datosOrganismoEnte.setPersonalizacion(Personalizacion
				.findPersonalizacion(variable));

		// Traer datos de la tabla datosOrganismoEnte para su actualizacion
		query = DatosOrganismoEnte
				.findDatosOrganismoEntesByRifEquals(datosOrganismoEnte
						.getOrganismoEnte().getRif().toString());
		List<DatosOrganismoEnte> listDO = query.getResultList();
		for (DatosOrganismoEnte ente : listDO) {
			variable = ente.getId();
		}
		estatus = datosOrganismoEnte.getOrganismoEnte().getEstatus()
				.getNombre();
		datosOrganismoEnte.setDatosOrganismoEnte(DatosOrganismoEnte
				.findDatosOrganismoEnte(variable));
		// Mapa de Modelos
		modelMap.addAttribute("datosOrganismoEnte", datosOrganismoEnte);
		modelMap.addAttribute("estadoes", Estado.findAllEstadoes());
		modelMap.addAttribute("ciudads", Ciudad.findAllCiudads());
		modelMap.addAttribute("municipioses", Municipios.findAllMunicipioses());
		modelMap.addAttribute("codigoareas", CodigoArea.findAllCodigoAreas());
		modelMap.addAttribute("estadoauditors",
				EstadoAuditor.findAllEstadoAuditors());
		modelMap.addAttribute("organismoentes",
				OrganismoEnte.findAllOrganismoEntes());
		modelMap.addAttribute("tipoorganismoes",
				TipoOrganismo.findAllTipoOrganismoes());
		modelMap.addAttribute("tipopersonarifs",
				TipoPersonaRif.findAllTipoPersonaRifs());
		return "organismoente/update";
	}

	/**
	 * 
	 * @param id
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "/organismoente/{id}", method = RequestMethod.GET)
	public String show(@PathVariable("id") Long id, ModelMap modelMap) {
		long variable = 0;

		if (id == null)
			throw new IllegalArgumentException("An Identifier is required");
		OrganismoEnteForm datosOrganismoEnte = new OrganismoEnteForm();
		datosOrganismoEnte
				.setOrganismoEnte(OrganismoEnte.findOrganismoEnte(id));
		// traer datos de la tabla Personalizacion para su actualizacion
		Query query = Personalizacion
				.findPersonalizacionsByRifEquals(datosOrganismoEnte
						.getOrganismoEnte().getRif().toString());
		List<Personalizacion> list = query.getResultList();
		for (Personalizacion per : list) {
			variable = per.getId();
			break;
		}
		datosOrganismoEnte.setPersonalizacion(Personalizacion
				.findPersonalizacion(variable));

		// Traer datos de la tabla datosOrganismoEnte para su actualizacion
		query = DatosOrganismoEnte
				.findDatosOrganismoEntesByRifEquals(datosOrganismoEnte
						.getOrganismoEnte().getRif().toString());
		List<DatosOrganismoEnte> listDO = query.getResultList();
		for (DatosOrganismoEnte ente : listDO) {
			variable = ente.getId();
		}
		datosOrganismoEnte.setDatosOrganismoEnte(DatosOrganismoEnte
				.findDatosOrganismoEnte(variable));
		// Mapa de Modelos
		modelMap.addAttribute("datosOrganismoEnte", datosOrganismoEnte);
		return "organismoente/show";
	}
	/**
	 * 
	 * @param page
	 * @param size
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "/organismoente", method = RequestMethod.GET)
	public String list(
			@RequestParam(value = "page", required = false) Integer page,
			@RequestParam(value = "size", required = false) Integer size,
			ModelMap modelMap) {
		Util util = new Util();
		String out = util.rolUsuarioLoggeado();

		if (out.equals("[ADMIN_INSTITUCION]")) {
			modelMap.addAttribute("organismoentes", OrganismoEnte
					.findOrganismoEntesByRifEquals(util.obtenerRif())
					.getResultList());
		} else {
			modelMap.addAttribute("organismoentes",
					OrganismoEnte.findAllOrganismoEntes());
		}
		return "organismoente/list";
	}
}